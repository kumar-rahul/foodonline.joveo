
// 'use strict';

// com.joveo.app.factory('ordersummary', function() {
//   console.log("app service : ordersummary");
//   var order = {};

//   return {
//     setOrderSummary: function(orderdata) {
//     	console.log('func_setOrderSummary',orderdata);
//       order.summary = orderdata;
//     },
//     getOrderSummary: function() {
//     	console.log('func_getOrderSummary');
//       return order.summary;
//     }

//   };

// });

