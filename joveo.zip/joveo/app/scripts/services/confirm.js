// 'use strict';

// com.joveo.app.factory('ordersummary', function() {
//   console.log("app service : ordersummary");
//   var user = {};
//   var count =0;

//   return {
//     setUserInfo: function(user) {
//     	console.log('func_setOrderSummary',user);
//     	count++;
//       user.orderid = "fzl"+count;
//       user.info = user;
//     },
//     getUserInfo: function() {
//     	console.log('func_getOrderSummary');
//       return order.summary;
//     }

//   };

// });
